from flask import Flask, render_template, request, jsonify,session,url_for,redirect
import pymysql

app = Flask(__name__)

# MySQL configurations
MYSQL_HOST = 'localhost'
MYSQL_USER = 'root'
MYSQL_PASSWORD = 'Admin123'
MYSQL_DB = 'hrm2'

# Connect to MySQL
conn = pymysql.connect(host=MYSQL_HOST, user=MYSQL_USER, password=MYSQL_PASSWORD, db=MYSQL_DB, cursorclass=pymysql.cursors.DictCursor)

@app.route("/")
def home():
    return  render_template("home/home.html")

@app.route("/about")
def about():
    return  render_template("home/about.html")

@app.route("/filters")
def filters():
    return  render_template("home/filters.html")

@app.route("/login")
def login():
    return  render_template("home/login.html")


@app.route("/newAccount")
def newAccount():
    return  render_template("home/newAccount.html")

@app.route("/forget")
def forget():
    return  render_template("home/forget.html")

@app.route("/filters/profile")
def profile():
    return  render_template("filters/profile.html")

@app.route("/filters/support")
def support():
    return  render_template("filters/support.html")

@app.route("/filters/publications")
def publications():
    return  render_template("filters/publications.html")

@app.route("/filters/tlp")
def tlp():
    return  render_template("filters/tlp.html")

@app.route("/filters/certifications")
def certifications():
    return  render_template("filters/certifications.html")

@app.route("/filters/conference")
def conference():
    return  render_template("filters/conferences.html")

import base64

@app.route('/filter_profile', methods=['POST'])
def filter_data():
    filters = request.form.getlist('filter[]')
    qualification_filters = request.form.getlist('qualification[]')
    dep_filters = request.form.getlist('dep[]')
    print(dep_filters)
    sql_query = """
        SELECT Name,Email,Mobile,Designation,HighestQulification,Department, d.*, TO_BASE64(e.Photo) AS Photo_Base64
        FROM employee e
        INNER JOIN degree d ON e.EmployeeId = d.EmployeeId
        WHERE e.HighestQulification = d.degree
    """
    params = []
    
    # Build the filter condition for designations
    if filters:
        sql_query += " AND ("
        sql_query += " OR ".join(["e.Designation = %s" for _ in range(len(filters))])
        sql_query += ")"
        params.extend(filters)
    
    # Build the filter condition for qualifications
    if qualification_filters:
        sql_query += " AND ("
        sql_query += " OR ".join(["e.HighestQulification = %s" for _ in range(len(qualification_filters))])
        sql_query += ")"
        params.extend(qualification_filters)

    if dep_filters:
        sql_query += " AND ("
        sql_query += " OR ".join(["e.Department = %s" for _ in range(len(dep_filters))])
        sql_query += ")"
        params.extend(dep_filters)

        
    with conn.cursor() as cursor:
        cursor.execute(sql_query, params)
        result = cursor.fetchall()

    # Convert the binary image data to base64 encoded strings


    return jsonify(data=result)

@app.route('/filter_support', methods=['POST'])
def filter_support():
    support_filter = request.form.getlist('support[]')
    print("Support Filter: ", support_filter)
    scope_filter = request.form.getlist('scope[]')
    print("Scope Filter: ", scope_filter)
    year_filter = request.form.getlist('year')
    if year_filter == ['']:
        year_filter = []
    print("Scope Filter: ", year_filter)
    dep_filters = request.form.getlist('dep[]')
    print("Dept Filters: ", dep_filters)
    sql_query = """
        SELECT Name,Email,Mobile,Designation,HighestQulification,Department, d.*, TO_BASE64(e.Photo) AS Photo_Base64
        FROM employee e
        INNER JOIN support d ON e.EmployeeId = d.EmployeeId
        
    """
    params = []
    
    # Build the filter condition for designations
    if support_filter:
        sql_query += " AND ("
        sql_query += " OR ".join(["d.Support = %s" for _ in range(len(support_filter))])
        sql_query += ")"
        params.extend(support_filter)
    
    if scope_filter:
        sql_query += " AND ("
        sql_query += " OR ".join(["d.Scope = %s" for _ in range(len(scope_filter))])
        sql_query += ")"
        params.extend(scope_filter)

    if year_filter:
        sql_query += " AND ("
        sql_query += " OR ".join(["d.Acc_Year = %s" for _ in range(len(year_filter))])
        sql_query += ")"
        params.extend(year_filter)
    
    if dep_filters:
        sql_query += " AND ("
        sql_query += " OR ".join(["e.Department = %s" for _ in range(len(dep_filters))])
        sql_query += ")"
        params.extend(dep_filters)
    
            
    with conn.cursor() as cursor:
        cursor.execute(sql_query, params)
        result = cursor.fetchall()


    return jsonify(data=result)


@app.route('/filter_tlp', methods=['POST'])
def filter_tlp():
    year_filter = request.form.getlist('year[]')
    print("Support Filter: ", year_filter)
    sem_filter = request.form.getlist('sem[]')
    print("Scope Filter: ", sem_filter)
    sec_filter = request.form.getlist('sec[]')
    print("Scope Filter: ", sec_filter)
    year_filter = request.form.getlist('year')
    if year_filter == ['']:
        year_filter = []
    print("Scope Filter: ", year_filter)
    dep_filters = request.form.getlist('dep[]')
    print("Dept Filters: ", dep_filters)
    sql_query = """
        SELECT Name,Email,Mobile,Designation,HighestQulification,Department, d.*, TO_BASE64(e.Photo) AS Photo_Base64
        FROM employee e
        INNER JOIN tlp d ON e.EmployeeId = d.EmployeeId
        
    """
    params = []
    
    # Build the filter condition for designations
    if year_filter:
        sql_query += " AND ("
        sql_query += " OR ".join(["d.Year = %s" for _ in range(len(year_filter))])
        sql_query += ")"
        params.extend(year_filter)
    
    if sem_filter:
        sql_query += " AND ("
        sql_query += " OR ".join(["d.Scope = %s" for _ in range(len(sem_filter))])
        sql_query += ")"
        params.extend(sem_filter)

    if year_filter:
        sql_query += " AND ("
        sql_query += " OR ".join(["d.Acc_Year = %s" for _ in range(len(year_filter))])
        sql_query += ")"
        params.extend(year_filter)
    
    if dep_filters:
        sql_query += " AND ("
        sql_query += " OR ".join(["e.Department = %s" for _ in range(len(dep_filters))])
        sql_query += ")"
        params.extend(dep_filters)
    
            
    with conn.cursor() as cursor:
        cursor.execute(sql_query, params)
        result = cursor.fetchall()


    return jsonify(data=result)




if __name__ == '__main__':
    app.run(debug=True)
