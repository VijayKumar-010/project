$(document).ready(function () {
  // Define CSS styles for the profile cards
  var profileStyles = `
          .profile-card {
              display: flex;
              align-items: center;
              width: 100%; /* Adjust width as needed */
              padding: 10px;
              border: 1px solid #ccc;
              border-radius: 5px;
              margin-bottom: 20px;
          }
    
          .profile-picture {
              flex: 0 0 100px; /* 100px for the photo width */
              margin-right: 20px;
          }
    
          .profile-picture img {
              width: 100%;
              border-radius: 50%;
          }
    
          .profile-details {
              flex: 1;
          }
    
          .profile-details p {
              margin: 5px 0;
          }
    
          .roles-dropdown {
              margin-top: 10px;
              margin-left: 20px; /* Adjust margin as needed */
          }
  
          .teaching-table {
              margin-top: 10px;
          }
      `;

  // Append the styles to the <head> of the document
  $("head").append("<style>" + profileStyles + "</style>");

  $("#filterForm").submit(function (event) {
    event.preventDefault();
    $.ajax({
      type: "POST",
      url: "/filter_tlp",
      data: $("#filterForm").serialize(),
      success: function (response) {
        $("#filteredData").html("");
        if (response.data.length > 0) {
          // Group data by person
          var groupedData = groupDataByPerson(response.data);

          // Create a table to display profiles
          var tableHtml = "<table>";

          // Iterate through each person's data
          var rowIndex = 0;
          $.each(groupedData, function (personName, personData) {
            if (rowIndex % 2 === 0) {
              // Start a new row
              tableHtml += "<tr>";
            }

            // Create the profile HTML
            var profileHtml =
              "<td>" +
              '<div class="profile-card">' +
              '<div class="profile-picture">' +
              '<img src="' +
              personData[0].Photo_Base64 +
              '" alt="Profile Picture">' + // Add employee photo
              "</div>" +
              '<div class="profile-details">' +
              "<p><strong>Name:</strong> " +
              personName +
              "</p>" +
              "<p><strong>Department:</strong> " + // Add department
              personData[0].Department +
              "</p>" +
              "<p><strong>Scope:</strong> " +
              personData[0].Scope +
              "</p>" +
              "<p><strong>Academic Year:</strong> " + // Corrected spelling
              personData[0].Acc_Year +
              "</p>" +
              "<p><strong>Support:</strong> " +
              personData[0].Support +
              "</p>" +
              '<select class="roles-dropdown">' + // Move roles dropdown here
              '<option value="Roles" selected>Roles</option>'; // Initial value
            $.each(personData, function (index, row) {
              profileHtml +=
                '<option value="' +
                index +
                '">Teaching and Learning Data</option>';
            });
            profileHtml += "</select></div>";

            // Add the teaching table
            profileHtml += '<div class="teaching-table" style="display:none;">';
            profileHtml += "<table>";
            profileHtml +=
              "<thead><tr><th>Course</th><th>Course Code</th><th>Year</th><th>Semester</th><th>Sec</th><th>Scheduled Classes</th><th>Held Classes</th><th>No. of Students Registered</th><th>No. of Students Passed</th><th>No. of Students Given Feedback</th><th>Feedback Result</th></tr></thead>";
            profileHtml += "<tbody>";
            $.each(personData, function (index, row) {
              profileHtml += "<tr>";
              profileHtml += "<td>" + row.Course + "</td>";
              profileHtml += "<td>" + row.CourseCode + "</td>";
              profileHtml += "<td>" + row.Year + "</td>";
              profileHtml += "<td>" + row.Semester + "</td>";
              profileHtml += "<td>" + row.Sec + "</td>";
              profileHtml += "<td>" + row.ScheduledClasses + "</td>";
              profileHtml += "<td>" + row.HeldClasses + "</td>";
              profileHtml += "<td>" + row.No_ofStudentsRegistered + "</td>";
              profileHtml += "<td>" + row.No_ofStudentsPassed + "</td>";
              profileHtml += "<td>" + row.No_ofStudentsGivenFeedback + "</td>";
              profileHtml += "<td>" + row.FeedbackResult + "</td>";
              profileHtml += "</tr>";
            });
            profileHtml += "</tbody></table></div></div></td>";

            // Append the profile HTML to the table row
            tableHtml += profileHtml;

            if (rowIndex % 2 === 1) {
              // End the row
              tableHtml += "</tr>";
            }

            rowIndex++;
          });

          // Close the table
          tableHtml += "</table>";

          // Append the table to the filteredData container
          $("#filteredData").html(tableHtml);

          // Dropdown change event to toggle teaching table
          $(".roles-dropdown").change(function () {
            var selectedIndex = $(this).val();
            $(this).parent().find(".teaching-table").hide();
            $(this)
              .parent()
              .find(".teaching-table:eq(" + selectedIndex + ")")
              .show();
          });
        } else {
          $("#filteredData").html("No data found.");
        }
      },
    });
  });

  // Function to group data by person
  function groupDataByPerson(data) {
    var groupedData = {};
    $.each(data, function (index, row) {
      if (!groupedData[row.Name]) {
        groupedData[row.Name] = [];
      }
      groupedData[row.Name].push(row);
    });
    return groupedData;
  }
});
