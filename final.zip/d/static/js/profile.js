$(document).ready(function () {
  // Define CSS styles for the profile cards
  var profileStyles = `
    .profile-card {
      display: flex;
      align-items: center;
      width: 100%; /* Adjust width as needed */
      padding: 10px;
      border: 1px solid #ccc;
      border-radius: 5px;
      margin-bottom: 20px;
    }

    .profile-picture {
      flex: 0 0 100px; /* 100px for the photo width */
      margin-right: 20px;
    }

    .profile-picture img {
      width: 100%;
      border-radius: 50%;
    }

    .profile-details {
      flex: 1;
    }

    .profile-details p {
      margin: 5px 0;
    }
  `;

  // Append the styles to the <head> of the document
  $("head").append("<style>" + profileStyles + "</style>");

  $("#filterForm").submit(function (event) {
    event.preventDefault();
    $.ajax({
      type: "POST",
      url: "/filter_profile",
      data: $("#filterForm").serialize(),
      success: function (response) {
        $("#filteredData").html("");
        if (response.data.length > 0) {
          var profiles = "<table><tr>"; // Start table

          // Iterate through each employee profile
          $.each(response.data, function (index, row) {
            // Create the profile HTML
            var profile =
              "<td>" +
              '<div class="profile-card">' +
              '<div class="profile-picture">' +
              '<a href="/login/' +
              row.EmployeeId +
              '">' + // Link to the employee's profile page
              '<img src="data:image/png;base64,' +
              row.Photo_Base64 +
              '" alt="Profile Picture"></a></div>' + // Use the base64 encoded image data here
              '<div class="profile-details">' +
              "<p><strong>Name:</strong> " +
              row.Name +
              "</p>" +
              "<p><strong>Email:</strong> " +
              row.Email +
              "</p>" +
              "<p><strong>Mobile:</strong> " +
              row.Mobile +
              "</p>" +
              "<p><strong>Designation:</strong> " +
              row.Designation +
              "</p>" +
              "<p><strong>Department:</strong> " +
              row.Department +
              "</p>" +
              "<p><strong>Highest Qualification:</strong> " +
              row.HighestQulification +
              "</p>" +
              "<p><strong>University:</strong> " +
              row.University +
              "</p>" +
              "</div>" +
              "</div>" +
              "</td>";

            profiles += profile;

            // Start a new row after every third profile
            if ((index + 1) % 3 === 0) {
              profiles += "</tr><tr>"; // Close the row and start a new one
            }
          });

          profiles += "</tr></table>"; // Close the table
          $("#filteredData").html(profiles);
        } else {
          $("#filteredData").html("No data found.");
        }
      },
    });
  });
});
