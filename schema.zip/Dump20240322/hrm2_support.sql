CREATE DATABASE  IF NOT EXISTS `hrm2` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `hrm2`;
-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: localhost    Database: hrm2
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `support`
--

DROP TABLE IF EXISTS `support`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `support` (
  `EmployeeID` varchar(30) DEFAULT NULL,
  `Role` varchar(1000) DEFAULT NULL,
  `Scope` varchar(1000) DEFAULT NULL,
  `Support` varchar(1000) DEFAULT NULL,
  `Acc_Year` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `support`
--

LOCK TABLES `support` WRITE;
/*!40000 ALTER TABLE `support` DISABLE KEYS */;
INSERT INTO `support` VALUES ('IT_07','Exam Squad','Department','Administration','2021-22'),('IT_07','Class Teacher','Department','Administration','2021-22'),('IT_07','Discipline committee member','Department','Administration','2021-22'),('IT_07','Project Batches Guided-1','Department','Student','2021-22'),('IT_07','Mentoring/Mid and Sem exam duties','Institute','Student','2021-22'),('IT_08','Students Achievements Collection','Department','Administration','2021-22'),('IT_08','Class Teacher','Department','Administration','2021-22'),('IT_08','News Letter Preparation','Department','Administration','2021-22'),('IT_08','Google Sheets creation and managing','Department','Administration','2021-22'),('IT_08','Sports Commitee member','Institute','Administration','2021-22'),('IT_08','Project Batches Guided-1','Department','Student','2021-22'),('IT_08','Mentoring/Mid and Sem exam duties','Institute','Student','2021-22'),('IT_10','ACOE','Institute','Administration','2021-22'),('IT_10','Class Teacher','Department','Administration','2021-22'),('IT_10','Result Analysis Coordinator','Department','Administration','2021-22'),('IT_10','Project Batches Guided-2','Department','Student','2021-22'),('IT_10','Content Development-IOT Manual ','Institute','Student','2021-22'),('IT_10','Mentoring/Mid and Sem exam duties','Institute','Student','2021-22'),('IT_04','Time Table Coordinator/Dept Events Coordinator','Department','Administration','2020-21'),('IT_04','Staff Welfare committee and SC/ST committee','Institute','Administration','2020-21'),('IT_04','Remedial Classes for CN-5','Department','Student','2020-21'),('IT_04','Project Batches Guided-1','Department','Student','2020-21'),('IT_04','Prepared Content for ACD(18IT502) Subject','Institute','Student','2020-21'),('IT_04','Mid and Sem exam duties/Spot valuation','Institute','Student','2020-21'),('IT_04','Time Table Coordinator/Dept Events Coordinator','Department','Administration','2021-22'),('IT_04','Staff Welfare committee and SC/ST committee','Institute','Administration','2021-22'),('IT_04','Remedial Classes-6','Department','Student','2021-22'),('IT_04','Project Batches Guided-1','Department','Student','2021-22'),('IT_04','Prepared Content for ACD(18IT502) Subject','Institute','Student','2021-22'),('IT_04','Mid and Sem exam duties/Spot valuation','Institute','Student','2021-22'),('IT_04','ACOE','Institute','Administration','2022-23'),('IT_04','Result Analysis','Department','Administration','2022-23'),('IT_04','Remedial Classes for CN and CP-12','Department','Student','2022-23'),('IT_04','Project Batches Guided-2','Department','Student','2022-23'),('IT_04','Mentoring','Department','Student','2022-23'),('IT_06','Class Teacher','Department','Administration','2022-23'),('IT_06','Mentoring Examination Duties','Department','Administration','2022-23'),('IT_03','Class Coordinator for 6&7 semester of Y19 batch section-B','Department','Administration','2022-23'),('IT_03','Mentoring Examination Duties','Department','Student','2022-23'),('IT_15','class teacher','Department','Administration','2022-23'),('IT_15','IIC-Member','Department','Administration','2022-23'),('IT_15','Department R&D coordinator','Department','Administration','2022-23'),('IT_15','Mentoring Examination Duties','Department','Student','2022-23'),('IT_15','External Key preparation','Department','Student','2022-23'),('IT_15','Spot Evaluation','Department','Student','2022-23'),('IT_05','ECAP CO-Ordinator','institute level','Administration','2022-23'),('IT_05','Spot Evaluation','Department','Student','2022-23'),('IT_05','Exam duties','Department','Student','2022-23'),('IT_05','Schemes Preparation','Department','Student','2022-23'),('IT_13','Class Teacher','Department','Administration','2022-23'),('IT_13','Department library in-charge','Department','Administration','2022-23'),('IT_13','lab in-charge','Department','Administration','2022-23'),('IT_13','Corporate social responsibility','Department','Administration','2022-23'),('IT_13','Examination duties','Department','Student','2022-23'),('IT_13','Mentoring','Department','Student','2022-23');
/*!40000 ALTER TABLE `support` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-03-22 16:30:08
