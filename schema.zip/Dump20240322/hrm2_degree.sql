CREATE DATABASE  IF NOT EXISTS `hrm2` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `hrm2`;
-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: localhost    Database: hrm2
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `degree`
--

DROP TABLE IF EXISTS `degree`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `degree` (
  `EmployeeID` varchar(30) DEFAULT NULL,
  `Degree` varchar(300) DEFAULT NULL,
  `University` varchar(300) DEFAULT NULL,
  `YearOfDegree` int DEFAULT NULL,
  `Specilization` varchar(300) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `degree`
--

LOCK TABLES `degree` WRITE;
/*!40000 ALTER TABLE `degree` DISABLE KEYS */;
INSERT INTO `degree` VALUES ('IT_01','Ph.D','ANU',2022,NULL),('IT_01','M.Tech','JNTU,Kakinada',2002,NULL),('IT_01','M.Tech','Delhi Uni.',1997,NULL),('IT_01','B.Tech','ANU',1995,NULL),('IT_01','Intermediate','BIE',1991,NULL),('IT_01','SSC','BSE',1989,NULL),('IT_02','Ph.D','Monad University',2013,NULL),('IT_02','M.Tech','AAIDU',2006,NULL),('IT_02','B.Tech','Karnataka Uni.',1994,NULL),('IT_02','Intermediate','BIE',1989,NULL),('IT_02','SSC','BSE',1987,NULL),('IT_03','Ph.D','SRM',NULL,NULL),('IT_03','M.Tech','ANU',2009,NULL),('IT_03','B.Tech','JNTU',2006,NULL),('IT_03','Intermediate','BIE',2002,NULL),('IT_03','SSC','BSE',2000,NULL),('IT_04','Ph.D','Andhra University',NULL,NULL),('IT_04','M.Tech','Andhra Uni.',2008,NULL),('IT_04','B.Tech','ANU',2003,NULL),('IT_04','Intermediate','BIE',1998,NULL),('IT_04','SSC','BSE',1996,NULL),('IT_05','M.Tech','JNTU',2005,NULL),('IT_05','B.Tech','JNTU',2002,NULL),('IT_05','Diploma','SBTET',1995,NULL),('IT_05','SSC','BSE',1991,NULL),('IT_06','Ph.D','Gitam University',2023,NULL),('IT_06','M.Tech','Satyabhama Univesity',2009,NULL),('IT_07','B.Tech','JNTU',2006,NULL),('IT_06','Intermediate','BIE',1999,NULL),('IT_06','SSC','BSE',1997,NULL),('IT_07','Ph.D','Bharat University',NULL,NULL),('IT_07','M.Tech','JNTU',2010,NULL),('IT_07','B.Tech','JNTU',2006,NULL),('IT_07','Intermediate','BIE',2002,NULL),('IT_07','SSC','BSE',2000,NULL),('IT_08','Ph.D','University of Technology',NULL,NULL),('IT_08','M.Tech','NIT,Calicut',2009,NULL),('IT_08','B.Tech','JNTUH',2006,NULL),('IT_08','Diploma','SBTET',2002,NULL),('IT_08','SSC','BSE',1999,NULL),('IT_09','M.Tech','ANU',2010,NULL),('IT_09','B.Tech','JNTU',2007,NULL),('IT_09','Intermediate','BIE',2003,NULL),('IT_09','SSC','BSE',2001,NULL),('IT_10','Ph.D','Andhra University',NULL,NULL),('IT_10','M.Tech','ANU',2011,NULL),('IT_10','B.Tech','JNTU',2009,NULL),('IT_10','Diploma','SBTET',2005,NULL),('IT_10','SSC','BSE',2003,NULL),('IT_11','Ph.D','Andhra University',2023,NULL),('IT_11','M.Tech','ANU',2005,NULL),('IT_11','B.Tech','JNTU',2003,NULL),('IT_11','Intermediate','BIE',1999,NULL),('IT_11','SSC','BSE',1997,NULL),('IT_12','M.Tech','Anna University',2011,NULL),('IT_12','B.Tech','JNTU',2009,NULL),('IT_12','Intermediate','BIE',2005,NULL),('IT_12','SSC','BSE',2003,NULL),('IT_13','Ph.D','Veltech',NULL,NULL),('IT_13','M.Tech','ANU',2013,NULL),('IT_13','B.Tech','JNTU,Kakinada',2010,NULL),('IT_13','Diploma','SBTET',2005,NULL),('IT_13','SSC','BSE',1999,NULL),('IT_14','Ph.D','JNTUK',NULL,NULL),('IT_14','M.Tech','ANU',2011,NULL),('IT_14','B.Tech','JNTUK',2009,NULL),('IT_14','Intermediate','BIE',2005,NULL),('IT_14','SSC','BSE',2003,NULL),('IT_15','Ph.D','Sri satya sai university',2021,NULL),('IT_15','M.Tech','JNTUK',2010,NULL),('IT_15','B.Tech','JNTUH',2005,NULL),('IT_15','Intermediate','BIE',2001,NULL),('IT_15','SSC','BSE',1999,NULL),('IT_16','Ph.D','JNTUA',NULL,NULL),('IT_16','M.Tech','AU',2005,NULL),('IT_16','B.Tech','JNTUH',2002,NULL),('IT_16','Intermediate','BIE',1998,NULL),('IT_16','SSC','BSE',1995,NULL);
/*!40000 ALTER TABLE `degree` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-03-22 16:30:09
