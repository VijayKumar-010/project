CREATE DATABASE  IF NOT EXISTS `hrm2` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `hrm2`;
-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: localhost    Database: hrm2
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `employee`
--

DROP TABLE IF EXISTS `employee`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employee` (
  `Photo` blob,
  `EmployeeID` varchar(30) NOT NULL,
  `Name` varchar(100) DEFAULT NULL,
  `Designation` varchar(100) DEFAULT NULL,
  `Department` varchar(100) DEFAULT NULL,
  `DateOfJoining` date DEFAULT NULL,
  `Email` varchar(100) DEFAULT NULL,
  `Mobile` int DEFAULT NULL,
  `DateOfPromotion` date DEFAULT NULL,
  `HighestQulification` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`EmployeeID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee`
--

LOCK TABLES `employee` WRITE;
/*!40000 ALTER TABLE `employee` DISABLE KEYS */;
INSERT INTO `employee` VALUES (NULL,'IT_01','Dr. N. Siva Ram Prasad','Professor','IT','1997-07-11',NULL,NULL,NULL,'Ph.D'),(NULL,'IT_02','Dr.K.SrinivasaRao','Associate Professor','IT','2007-04-19',NULL,NULL,NULL,'Ph.D'),(NULL,'IT_03','Mr.P.A.V.Krishna Rao','Assistant Professor','IT','2009-07-08',NULL,NULL,NULL,'M.Tech'),(NULL,'IT_04','Mr.G.Prasad','Assistant Professor','IT','2009-06-08',NULL,NULL,NULL,'M.Tech'),(NULL,'IT_05','Mr.K.Bhaskara Rao','Assistant Professor','IT','2009-06-24',NULL,NULL,NULL,'M.Tech'),(NULL,'IT_06','Dr.B.Krishnaiah','Assistant Professor','IT','2009-07-01',NULL,NULL,NULL,'Ph.D'),(NULL,'IT_07','Mr.M.Praveen Kumar','Assistant Professor','IT','2009-09-09',NULL,NULL,NULL,'M.Tech'),(NULL,'IT_08','Mr.N.Srinivasarao','Assistant Professor','IT','2009-12-15',NULL,NULL,NULL,'M.Tech'),(NULL,'IT_09','Mr.K SaiPrasanth','Assistant Professor','IT','2010-03-08',NULL,NULL,NULL,'M.Tech'),(NULL,'IT_10','Mr.P RatnaPrakash','Assistant Professor','IT','2010-07-13',NULL,NULL,NULL,'M.Tech'),(NULL,'IT_11','Dr.P Ravi Kumar','Assistant Professor','IT','2011-06-10',NULL,NULL,NULL,'Ph.D'),(NULL,'IT_12','Mr. K Suresh Kumar','Assistant Professor','IT','2011-07-11',NULL,NULL,NULL,'M.Tech'),(NULL,'IT_13','Mr. S Ratna Babu','Assistant Professor','IT','2016-06-16',NULL,NULL,NULL,'M.Tech'),(NULL,'IT_14','Mr. Mastanaiah Naidu.Y','Assistant Professor','IT','2022-03-22',NULL,NULL,NULL,'M.Tech'),(NULL,'IT_15','Dr.P.Sreedhar','Assistant Professor','IT','2022-07-01',NULL,NULL,NULL,'Ph.D'),(NULL,'IT_16','Mr. B.B.K.Prasad','Assistant Professor','IT','2022-07-01',NULL,NULL,NULL,'M.Tech');
/*!40000 ALTER TABLE `employee` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-03-22 16:30:09
