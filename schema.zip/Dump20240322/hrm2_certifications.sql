CREATE DATABASE  IF NOT EXISTS `hrm2` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `hrm2`;
-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: localhost    Database: hrm2
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `certifications`
--

DROP TABLE IF EXISTS `certifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `certifications` (
  `EmployeeID` varchar(30) DEFAULT NULL,
  `CertificationName` varchar(100) DEFAULT NULL,
  `Provider` varchar(100) DEFAULT NULL,
  `StartingDate` date DEFAULT NULL,
  `CompletionDate` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `certifications`
--

LOCK TABLES `certifications` WRITE;
/*!40000 ALTER TABLE `certifications` DISABLE KEYS */;
INSERT INTO `certifications` VALUES ('IT_12','HTML5 Application Development Fundamentals','MTA Certification ',NULL,'2022-06-29'),('IT_12','Introduction Programming using Python','MTA Certification ',NULL,'2022-06-30'),('IT_12','The Joy of computing using Python','Swayam NPTEL ','2022-07-01','2022-10-01'),('IT_12','Data Science','Udemy ','2022-07-01','2022-10-01'),('IT_12','Machine Learning Appl','Udemy ','2022-07-01','2022-10-01'),('IT_14','Programming in Java in NPTEL','Swayam ','2022-07-01','2022-10-01'),('IT_14','Amazon Web Services','Udemy ','2023-06-01',NULL),('IT_06','Introduction to Internet of Things','Swayam NPTEL','2022-07-01','2022-10-01'),('IT_15','Machine Learning & Data Science','Udemy','2023-06-16',NULL),('IT_15','Complete python pro bootcamp','Udemy','2023-06-15',NULL),('IT_15','Network Security','Udemy','2023-06-15',NULL),('IT_13','The Complete Python Pro Bootcamp for 2023','Udemy',NULL,NULL),('IT_12','HTML5 Application Development Fundamentals','MTA Certification ',NULL,'2022-06-29'),('IT_12','Introduction Programming using Python','MTA Certification ',NULL,'2022-06-30'),('IT_12','The Joy of computing using Python','Swayam NPTEL ','2022-07-01','2022-10-01'),('IT_12','Data Science','Udemy ','2022-07-01','2022-10-01'),('IT_12','Machine Learning Appl','Udemy ','2022-07-01','2022-10-01'),('IT_14','Programming in Java in NPTEL','Swayam ','2022-07-01','2022-10-01'),('IT_14','Amazon Web Services','Udemy ','2023-06-01',NULL),('IT_06','Introduction to Internet of Things','Swayam NPTEL','2022-07-01','2022-10-01'),('IT_15','Machine Learning & Data Science','Udemy','2023-06-16',NULL),('IT_15','Complete python pro bootcamp','Udemy','2023-06-15',NULL),('IT_15','Network Security','Udemy','2023-06-15',NULL),('IT_13','The Complete Python Pro Bootcamp for 2023','Udemy',NULL,NULL);
/*!40000 ALTER TABLE `certifications` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-03-22 16:30:08
