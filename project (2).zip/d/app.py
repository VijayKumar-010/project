from flask import Flask, render_template, request, jsonify
import pymysql

app = Flask(__name__)

# MySQL configurations
MYSQL_HOST = 'localhost'
MYSQL_USER = 'root'
MYSQL_PASSWORD = 'Admin123'
MYSQL_DB = 'hrm2'

# Connect to MySQL
conn = pymysql.connect(host=MYSQL_HOST, user=MYSQL_USER, password=MYSQL_PASSWORD, db=MYSQL_DB, cursorclass=pymysql.cursors.DictCursor)

@app.route("/")
def home():
    return  render_template("home/home.html")

@app.route("/about")
def about():
    return  render_template("home/about.html")

@app.route("/filters")
def filters():
    return  render_template("home/filters.html")

@app.route("/login")
def login():
    return  render_template("home/login.html")

@app.route("/filters/profile")
def profile():
    return  render_template("filters/profile.html")

@app.route("/filters/support")
def support():
    return  render_template("filters/support.html")

@app.route("/filters/publications")
def publications():
    return  render_template("filters/publications.html")

@app.route("/filters/tlp")
def tlp():
    return  render_template("filters/tlp.html")

@app.route("/filters/certifications")
def certifications():
    return  render_template("filters/certifications.html")

@app.route("/filters/conference")
def conference():
    return  render_template("filters/conferences.html")

import base64

@app.route('/filter_profile', methods=['POST'])
def filter_data():
    filters = request.form.getlist('filter[]')
    qualification_filters = request.form.getlist('qualification[]')
    dep_filters = request.form.getlist('dep[]')
    sql_query = """
        SELECT Name,Email,Mobile,Designation,HighestQulification,Department, d.*, TO_BASE64(e.Photo) AS Photo_Base64
        FROM employee e
        INNER JOIN degree d ON e.EmployeeId = d.EmployeeId
        WHERE e.HighestQulification = d.degree
    """
    params = []
    
    # Build the filter condition for designations
    if filters:
        sql_query += " AND ("
        sql_query += " OR ".join(["e.Designation = %s" for _ in range(len(filters))])
        sql_query += ")"
        params.extend(filters)
    
    # Build the filter condition for qualifications
    if qualification_filters:
        sql_query += " AND ("
        sql_query += " OR ".join(["e.HighestQulification = %s" for _ in range(len(qualification_filters))])
        sql_query += ")"
        params.extend(qualification_filters)

    if dep_filters:
        sql_query += " AND ("
        sql_query += " OR ".join(["e.Department = %s" for _ in range(len(dep_filters))])
        sql_query += ")"
        params.extend(dep_filters)

        
    with conn.cursor() as cursor:
        cursor.execute(sql_query, params)
        result = cursor.fetchall()

    # Convert the binary image data to base64 encoded strings
    """for row in result:
        if row['Photo_Binary'] is not None:
            # Convert binary data to base64
            row['Photo_Binary'] = base64.b64encode(row['Photo_Binary']).decode('utf-8')"""

    return jsonify(data=result)

@app.route('/filter_support', methods=['POST'])
def filter_support():
    dep = request.form.getlist('dep[]')
    print(dep)
    acc = request.form.getlist('acc[]')
    print(acc)
    scope = request.form.getlist('scope[]')
    print(scope)
    support = request.form.getlist('support[]')
    print(support)
    sql_query = """
        SELECT Name,Email,Mobile,Designation,HighestQulification,Department, d.*, TO_BASE64(e.Photo) AS Photo_Base64
        FROM employee e
        INNER JOIN support d ON e.EmployeeId = d.EmployeeId
        
    """
    params = []
    
    # Build the filter condition for designations
    if dep:
        sql_query += " AND ("
        sql_query += " OR ".join(["e.Department = %s" for _ in range(len(dep))])
        sql_query += ")"
        params.extend(dep)
    
    # Build the filter condition for qualifications
    if scope:
        sql_query += " AND ("
        sql_query += " OR ".join(["d.Scope = %s" for _ in range(len(scope))])
        sql_query += ")"
        params.extend(scope)

    if support:
        sql_query += " AND ("
        sql_query += " OR ".join(["d.Support = %s" for _ in range(len(support))])
        sql_query += ")"
        params.extend(support)

    if acc:
        sql_query += " AND ("
        sql_query += " OR ".join(["d.Acc_Year = %s" for _ in range(len(acc))])
        sql_query += ")"
        params.extend(acc)

        
    with conn.cursor() as cursor:
        cursor.execute(sql_query, params)
        result = cursor.fetchall()

    # Convert the binary image data to base64 encoded strings
    """for row in result:
        if row['Photo_Binary'] is not None:
            # Convert binary data to base64
            row['Photo_Binary'] = base64.b64encode(row['Photo_Binary']).decode('utf-8')"""

    return jsonify(data=result)





if __name__ == '__main__':
    app.run(debug=True)
