$(document).ready(function () {
  $("#filterForm").submit(function (event) {
    event.preventDefault();
    $.ajax({
      type: "POST",
      url: "/filter_Publications",
      data: $("#filterForm").serialize(),
      success: function (response) {
        $("#filteredData").html("");
        if (response.data.length > 0) {
          var table =
            '<table border="1"><tr><th>Name</th><th>ISSN</th><th>Title</th><th>PaperTitle</th><th>Details</th><th>IndexedIn</th><th>Month</th><th>Year</th><th>CoverageYears</th></tr>';
          $.each(response.data, function (index, row) {
            table +=
              "<tr><td>" +
              row.Name +
              "</td><td>" +
              row.ISSN +
              "</td><td>" +
              row.Title +
              "</td><td>" +
              row.PaperTitle +
              "</td><td>" +
              row.Details +
              "</td><td>" +
              row.IndexedIn +
              "</td><td>" +
              row.Month +
              "</td><td>" +
              row.Year +
              "</td><td>" +
              row.CoverageYears +
              "</td></tr>";
          });
          table += "</table>";
          $("#filteredData").html(table);
        } else {
          $("#filteredData").html("No data found.");
        }
      },
    });
  });
});
